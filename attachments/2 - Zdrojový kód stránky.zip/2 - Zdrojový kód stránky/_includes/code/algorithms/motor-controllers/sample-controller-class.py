class SampleControllerClass:
    """Description of the class."""

    def __init__(self, ...):
        """Creates a controller object."""
        pass

    def set_goal(self, goal):
        """Sets the goal of the controller."""
        pass

    def get_value(self):
        """Returns the current controller value"""
        pass