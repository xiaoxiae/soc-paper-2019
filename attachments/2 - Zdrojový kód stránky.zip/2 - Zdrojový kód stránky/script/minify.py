"""Minifies website source files."""

from os import path, walk

import requests
import codecs

extensions = ("html", "css")
minifier_urls = ("https://html-minifier.com/raw", "https://cssminifier.com/raw")

# sizes for each extension before and after
size_before = [0] * len(extensions)
size_after = [0] * len(extensions)

# recursively find website source files
for root, subdirs, files in walk(path.join("..", "_site")):
    for file in files:
        if file.endswith(extensions):
            file_path = path.join(root, file)
            extension_index = extensions.index(file[file.index(".") + 1:])

            # add size before minifying
            size_before[extension_index] += path.getsize(file_path)

            # minifies the text
            url = minifier_urls[extension_index]
            data = {'input': open(file_path, 'rb').read()}
            response = requests.post(url, data=data)

            # minifies the text
            with codecs.open(file_path, 'w', 'utf-8') as f:
                f.write(response.text)

            # add size before minifying
            size_after[extension_index] += path.getsize(file_path)

# print minify stats
for i in range(len(extensions)):
    print(extensions[i].upper() + " compression rate: "\
          + str(round(size_after[i] / size_before[i] * 100, 2)) + "%,"\
          + "saved " + str(round((size_before[i] - size_after[i]) / 1024, 2))\
          + " KB")
