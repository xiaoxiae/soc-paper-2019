# Robotics Simplified Website
This repository contains the source code for [Robotics Simplified](http://robotics-simplified.com/).

The website is powered by Jekyll, based on the [just-the-docs](https://github.com/pmarsceill/just-the-docs) theme. Both the hosting and the domain name are provided by [WEDOS](https://hosting.wedos.com/).

For more information, see the [SOČ paper](https://github.com/xiaoxiae/soc-paper-2019) about the website.
